globalThis.NEXALGO_EXTENSION_CONFIG = {
  apiBaseUrl: 'http://localhost:8080/v1',
  webBaseUrl: 'http://localhost:3000/projects/nexalgo',
}
